import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

/**
 * Put a short phrase describing the program here.
 *
 * @author Bryce Hostetler
 *
 */
public final class DriverTabs {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private DriverTabs() {
    }

    /**
     * Constants used for various tasks.
     */
    private static final int TRIP = 5;
    private static final int DRIVER = 7;
    private static final int START_HOUR_DIGIT = 0;
    private static final int START_MIN_DIGIT = 3;
    private static final int END_HOUR_DIGIT = 6;
    private static final int END_MIN_DIGIT = 9;
    private static final int DISTANCE_SPACES = 3;
    private static final double MIN_PER_HOUR = 60.0;
    private static final double MIN_MPH = 5;
    private static final double MAX_MPH = 100;

    /**
     * Parses part of a string into an integer.
     *
     * @param dig1
     *            first substring index of the integer to be parsed
     * @param info
     *            string that contains information about the desired integer
     *            value
     * @return a valid integer value between 0 and 59
     * @ensures all strings parsed into integers are valid
     */
    static int hourMin(int dig1, String info) {

        int time = 0;
        if (info.charAt(dig1) == '0' && info.charAt(dig1 + 1) != '0') {
            time = Character.getNumericValue(info.charAt(dig1 + 1));
        } else if (info.charAt(dig1) != '0') {
            time = Integer.parseInt(info.substring(dig1, dig1 + 2));
        }
        return time;
    }

    /**
     * Update total distance and mileage traveled by each registered driver and
     * disregarding trips that have speeds of below 5mph or above 100mph.
     *
     * @param driver
     *            Driver whose trip log is being updated
     * @param data
     *            String of data that is used to update the driver log
     * @param records
     *            Map that holds current driving records of {@code driver}
     * @updates records
     */
    private static void updateStats(String driver, String data,
            Map<String, Double[]> records) {

        int hr1 = hourMin(START_HOUR_DIGIT, data);
        int min1 = hourMin(START_MIN_DIGIT, data);
        int hr2 = hourMin(END_HOUR_DIGIT, data);
        int min2 = hourMin(END_MIN_DIGIT, data);

        double hrToMin = (hr2 - hr1) * MIN_PER_HOUR;
        double minDiff = min2 - min1;
        double time = (hrToMin + minDiff) / MIN_PER_HOUR;

        String distance = data.substring(END_MIN_DIGIT + DISTANCE_SPACES);
        double miles = Double.parseDouble(distance);

        if (miles / time >= MIN_MPH && miles / time <= MAX_MPH) {
            Double[] temp = records.get(driver);
            temp[0] += time;
            temp[1] += miles;

            records.put(driver, temp);
        }
    }

    /**
     * Display all trip records of registered drivers.
     *
     * @param driver
     *            Entry that contains all trip info about a registered driver
     * @return output expected for the data provided
     */
    static String displayRecords(Entry<String, Double[]> driver) {

        String name = driver.getKey();
        Double[] dat = driver.getValue();
        long dispMiles = Math.round(dat[1]);
        long dispMph = Math.round(dat[1] / dat[0]);

        String output = "";
        if (dat[0] <= 0 && dat[1] <= 0) {
            output = name + ": 0 miles";
        } else {
            output = name + ": " + dispMiles + " miles @ " + dispMph + " mph";
        }

        return output;
    }

    /**
     *
     * @param input
     *            Buffered reader input that contains trip information
     * @return map containing all trip records for each registered driver
     */
    static Map<String, Double[]> dataExtraction(BufferedReader input) {

        Map<String, Double[]> driverDat = new HashMap<>();

        try {
            String line = input.readLine();

            while (line != null) {
                if (line.charAt(0) == 'D') {
                    String name = line.substring(DRIVER);
                    Double[] timeMiles = new Double[2];
                    timeMiles[0] = 0.0;
                    timeMiles[1] = 0.0;
                    driverDat.put(name, timeMiles);

                } else {
                    String driverInfo = line.substring(TRIP);
                    int space1 = driverInfo.indexOf(' ');
                    String tmpName = driverInfo.substring(0, space1);
                    updateStats(tmpName, driverInfo.substring(space1 + 1),
                            driverDat);
                }

                line = input.readLine();
            }
        } catch (IOException e) {
            System.err.println("Error reading from file");
        }

        return driverDat;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments.
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter a file name that has driver information: ");
        String data = in.nextLine();
        in.close();

        /*
         * Checking that the input file is opened successfully.
         */
        BufferedReader input;
        try {
            input = new BufferedReader(new FileReader(data));
        } catch (IOException e) {
            System.err.println("Error reading in file " + data);
            return;
        }

        /*
         * Reading data from the input file until the end of its stream.
         */
        Map<String, Double[]> driverDat = dataExtraction(input);

        /*
         * Closing the input file.
         */
        try {
            input.close();
        } catch (IOException e) {
            System.err.println("Couldn't close reader file.");
        }

        /*
         * Iterating over all elements processed from the input file.
         */
        Set<Entry<String, Double[]>> view = driverDat.entrySet();
        Iterator<Entry<String, Double[]>> display = view.iterator();

        while (display.hasNext()) {
            Entry<String, Double[]> tmpDriver = display.next();
            String disp = displayRecords(tmpDriver);
            System.out.println(disp);
        }
    }
}

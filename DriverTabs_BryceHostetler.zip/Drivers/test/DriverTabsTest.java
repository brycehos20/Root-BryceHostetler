import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

public final class DriverTabsTest {

    /**
     * Margin of error for assertEquals checking.
     */
    public static final double EPSILON = 0.1;

    /**
     * Creates and returns a {@code Map} constructed from a given input file.
     *
     * @param args
     *            provided map keys and values
     * @return the constructed map corresponding to {@code args}
     * @ensures createFromArgs = [map consisting of only strings as keys and
     *          only initialized double arrays of length 2 as values]
     */
    private static Map<String, Double[]> createFromArgs(String... args) {
        Map<String, Double[]> expected = new HashMap<>();

        int i = 0;
        while (i < args.length) {
            String name = args[i];
            i++;

            Double[] data = new Double[2];
            data[0] = Double.parseDouble(args[i]);
            i++;
            data[1] = Double.parseDouble(args[i]);
            i++;

            expected.put(name, data);
        }

        return expected;
    }

    /**
     * Rounds any expected test case doubles that are within a certain margin of
     * error.
     *
     * @param rounder
     *            Map that is used to correct any rounding issues
     * @param rounded
     *            Map being checked for rounding issues
     */
    private static void dataChecker(Map<String, Double[]> rounder,
            Map<String, Double[]> rounded) {
        Set<Map.Entry<String, Double[]>> view = rounder.entrySet();
        Iterator<Map.Entry<String, Double[]>> estimate = view.iterator();

        while (estimate.hasNext()) {
            Map.Entry<String, Double[]> compare = estimate.next();

            Double[] roundTo = compare.getValue();
            double[] rd = new double[2];
            rd[0] = roundTo[0];
            rd[1] = roundTo[1];

            assertTrue(rounded.containsKey(compare.getKey()));
            Double[] checkRounding = rounded.get(compare.getKey());
            double[] check = new double[2];
            check[0] = checkRounding[0];
            check[1] = checkRounding[1];

            assertArrayEquals(rd, check, EPSILON);
        }
    }

    /**
     * Creates an input stream from {@code file}.
     *
     * @param file
     *            file path used to create a new BufferedReader object
     * @return new BufferedReader object
     */
    private static BufferedReader reader(String file) {
        BufferedReader input = null;
        try {
            input = new BufferedReader(new FileReader(file));
        } catch (IOException e) {
            System.err.println("Error reading in file " + file);
        }

        return input;
    }

    /*
     * hourMin test cases
     */

    @Test
    public void doubleZeros() {
        int val = DriverTabs.hourMin(3, "10:00");
        assertEquals(0, val);
    }

    @Test
    public void leadingZero() {
        int val = DriverTabs.hourMin(3, "10:04");
        assertEquals(4, val);
    }

    @Test
    public void leadingNonZero() {
        int val = DriverTabs.hourMin(0, "10:30");
        assertEquals(10, val);
    }

    @Test
    public void noZeros() {
        int val = DriverTabs.hourMin(3, "10:32");
        assertEquals(32, val);
    }

    /*
     * displayRecords test cases
     */

    @Test
    public void noRecords() {
        Map<String, Double[]> test = createFromArgs("Dan", "0.0", "0.0");
        Set<Map.Entry<String, Double[]>> testPairs = test.entrySet();
        Iterator<Map.Entry<String, Double[]>> statements = testPairs.iterator();
        assertEquals("Dan: 0 miles",
                DriverTabs.displayRecords(statements.next()));
    }

    @Test
    public void records() {
        Map<String, Double[]> test = createFromArgs("Dan", "12.4", "921.5");
        Set<Map.Entry<String, Double[]>> testPairs = test.entrySet();
        Iterator<Map.Entry<String, Double[]>> statements = testPairs.iterator();
        assertEquals("Dan: 922 miles @ 74 mph",
                DriverTabs.displayRecords(statements.next()));
    }

    /*
     * Map construction tests
     */

    @Test
    public void oneArgNoDat() {
        Map<String, Double[]> m = DriverTabs
                .dataExtraction(reader("data/driverNoDat.txt"));
        Map<String, Double[]> mExpected = createFromArgs("Dan", "0.0", "0.0");

        dataChecker(m, mExpected);
    }

    @Test
    public void oneArgDat() {
        Map<String, Double[]> m = DriverTabs
                .dataExtraction(reader("data/driverDat.txt"));
        Map<String, Double[]> mExpected = createFromArgs("Dan", "9.1", "170.2");

        dataChecker(m, mExpected);
    }

    @Test
    public void multArgsNoDat() {
        Map<String, Double[]> m = DriverTabs
                .dataExtraction(reader("data/driversNoDat.txt"));
        Map<String, Double[]> mExpected = createFromArgs("Dan", "0.0", "0.0",
                "Liam", "0.0", "0.0", "Daniel", "0.0", "0.0");

        dataChecker(m, mExpected);
    }

    @Test
    public void multArgsDat() {
        Map<String, Double[]> m = DriverTabs
                .dataExtraction(reader("data/driversDat.txt"));
        Map<String, Double[]> mExpected = createFromArgs("Dan", "0.6", "11.9",
                "Liam", "1.7", "33.2", "Daniel", "5.0", "220.0");

        dataChecker(m, mExpected);
    }

    @Test
    public void belowFive() {
        Map<String, Double[]> m = DriverTabs
                .dataExtraction(reader("data/driversSubFive.txt"));
        Map<String, Double[]> mExpected = createFromArgs("Dan", "0.6", "11.9",
                "Liam", "1.7", "33.2", "Daniel", "0.0", "0.0");

        dataChecker(m, mExpected);
    }

    @Test
    public void aboveOneHundred() {
        Map<String, Double[]> m = DriverTabs
                .dataExtraction(reader("data/driversPlusHundred.txt"));
        Map<String, Double[]> mExpected = createFromArgs("Dan", "0.6", "11.9",
                "Liam", "1.7", "33.2", "Daniel", "0.0", "0.0");

        dataChecker(m, mExpected);
    }

    @Test
    public void multTripsForDriver() {
        Map<String, Double[]> m = DriverTabs
                .dataExtraction(reader("data/driversMultArgs.txt"));
        Map<String, Double[]> mExpected = createFromArgs("Dan", "0.0", "0.0",
                "Liam", "2.4", "45.1", "Daniel", "5.0", "220.0");

        dataChecker(m, mExpected);
    }
}
